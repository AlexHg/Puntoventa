<?php
	#servidor
	define('HOST', 'localhost');
	#usuario de la base de datos
	define('USER', 'root');
	#contraseña del usuario
	define('PASS', '');
	#base de datos (nombre)
	define('DB', 'punto_venta');
?>